#!/bin/bash

npm pack
